#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
#[cfg(flux)] extern crate flux_rs;
#[cfg(flux)] #[path = "/home/runner/work/wasmtime/wasmtime/verification/flux/file_read_specs.rs"] mod file_read_specs;
use std::fs::File;
use std::io;
use std::os::unix::fs::FileExt;
#[cfg_attr(flux, flux::sig(fn(&File, &mut [u8][@n], u64) -> Result<usize{v: v <= n}, io::Error>))]
pub(crate) fn read_at_cursor_unspecified(
    file: &File,
    buf: &mut [u8],
    pos: u64,
) -> io::Result<usize> {
    Ok(usize::MAX)
}
