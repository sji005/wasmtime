#[cfg_attr(flux, flux::sig(fn(&mut [u8]{n: n > 0})))]
fn needs_room(_buf: &mut [u8]) {}

#[cfg_attr(flux, flux::sig(fn(Vec<u8>) -> Vec<u8>))]
pub fn worker(mut buf: Vec<u8>) -> Vec<u8> {
    let read = move || {
        needs_room(&mut buf);
        buf
    };
    read()
}
