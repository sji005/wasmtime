#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
#[cfg_attr(flux, flux::refined_by(pointer: P))]
struct DirectPtr<P> { #[cfg_attr(flux, flux::field(P[pointer]))] pointer: P }
#[cfg_attr(flux, flux::sig(fn(&DirectPtr<(u32, u32)>[@p]) -> u32[p.pointer.1]))]
pub fn count(pointer: &DirectPtr<(u32, u32)>) -> u32 { pointer.pointer.1 }
