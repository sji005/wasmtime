use wiggle::GuestType;

#[cfg_attr(flux, flux::sig(fn() -> u32[5]))]
pub fn width() -> u32 { u32::guest_size() }
