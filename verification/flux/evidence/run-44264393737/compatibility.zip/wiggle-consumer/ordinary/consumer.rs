use wiggle::GuestType;

#[cfg_attr(flux, flux::sig(fn() -> u32[4]))]
pub fn width() -> u32 { u32::guest_size() }
