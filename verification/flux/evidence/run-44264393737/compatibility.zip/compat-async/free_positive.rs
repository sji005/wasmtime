#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
#[cfg_attr(flux, flux::sig(async fn(usize[@n]) -> usize[n]))]
pub async fn identity(n: usize) -> usize { n }
