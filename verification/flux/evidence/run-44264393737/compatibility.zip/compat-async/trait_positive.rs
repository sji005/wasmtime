#![allow(dead_code, async_fn_in_trait)]
#[cfg(flux)] extern crate flux_core;
pub trait Read { async fn read(&mut self, n: usize) -> usize; }
pub struct Reader;
impl Read for Reader {
    #[cfg_attr(flux, flux::sig(async fn(&mut Reader, usize[@n]) -> usize[n]))]
    async fn read(&mut self, n: usize) -> usize { n }
}
