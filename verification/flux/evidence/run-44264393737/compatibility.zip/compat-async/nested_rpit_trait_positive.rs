#![allow(dead_code, async_fn_in_trait)]
#[cfg(flux)] extern crate flux_core;
pub trait Read { fn read(&mut self, n: usize) -> impl std::future::Future<Output = usize> + Send; }
pub struct Reader;
impl Read for Reader {
    #[cfg_attr(flux, flux::sig(async fn(&mut Reader, usize[@n]) -> usize[n]))]
    async fn read(&mut self, n: usize) -> usize { async move { n }.await }
}
