use std::{fs::File, io, os::unix::fs::FileExt};

#[cfg_attr(flux, flux::sig(fn(&File, &mut [u8][@n]) -> Result<usize{c: c <= n}, io::Error>))]
fn read_into(file: &File, buf: &mut [u8]) -> io::Result<usize> {
    file.read_at(buf, 0)
}
pub fn worker(file: &File, n: usize) -> io::Result<usize> {
    let mut buf = vec![0; n];
    read_into(file, &mut buf)
}
