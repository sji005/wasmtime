#[cfg_attr(flux, flux::sig(fn(&mut [u8]{n: n > 0})))]
fn needs_room(_buf: &mut [u8]) {}

fn invoke(work: impl FnOnce() -> Vec<u8>) -> Vec<u8> {
    work()
}

#[cfg_attr(flux, flux::sig(fn(Vec<u8>{v: v.len > 0}) -> Vec<u8>))]
pub fn worker(mut buf: Vec<u8>) -> Vec<u8> {
    invoke(move || {
        needs_room(&mut buf);
        buf
    })
}
