#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
extern crate foreign_macro;
foreign_macro::unrelated!();
#[cfg_attr(flux, flux::sig(fn(bytes: &[u8][@n], index: usize{index < n}) -> u8))]
pub fn selected(bytes: &[u8], index: usize) -> u8 { bytes[bytes.len()] }
