#[macro_export] macro_rules! unrelated { () => { pub fn outside(bytes: &[u8]) -> u8 { bytes[bytes.len()] } }; }
