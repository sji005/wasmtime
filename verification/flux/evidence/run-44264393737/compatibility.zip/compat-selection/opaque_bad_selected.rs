#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
struct Counter { len: u32 }
impl Counter {
    fn iter(&self) -> impl ExactSizeIterator<Item = u32> + '_ {
        (0..self.len).map(move |i| i)
    }
}
#[cfg_attr(flux, flux::sig(fn(bytes: &[u8][@n], index: usize{index < n}) -> u8))]
pub fn selected(bytes: &[u8], index: usize) -> u8 { bytes[bytes.len()] }
