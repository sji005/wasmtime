use std::ops::Range;
#[cfg_attr(flux, flux::sig(fn(&Range<usize>[@r]) -> Range<usize>[r]))]
pub fn clone_range(r: &Range<usize>) -> Range<usize> { r.clone() }
