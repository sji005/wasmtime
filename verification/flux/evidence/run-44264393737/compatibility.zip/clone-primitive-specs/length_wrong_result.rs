use std::ops::Range;
#[cfg_attr(flux, flux::sig(fn(&Range<usize>[@r]) -> usize[if r.start <= r.end { r.end - r.start + 1 } else { 0 }]))]
pub fn range_length(r: &Range<usize>) -> usize { r.len() }
