use std::ops::Range;
#[cfg_attr(flux, flux::sig(fn(&Range<usize>[@r]) -> Range<usize>[Range { start: r.start, end: r.end + 1 }]))]
pub fn clone_range(r: &Range<usize>) -> Range<usize> { r.clone() }
