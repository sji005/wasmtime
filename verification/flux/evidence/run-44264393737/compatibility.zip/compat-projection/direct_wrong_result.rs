#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
#[cfg_attr(flux, flux::refined_by(base: int, count: int))]
pub struct DirectPtr {
    #[cfg_attr(flux, flux::field((u32[base], u32[count])))]
    pointer: (u32, u32),
}
#[cfg_attr(flux, flux::sig(fn(&DirectPtr[@p]) -> u32[p.count]))]
pub fn count(pointer: &DirectPtr) -> u32 { 0 }
