#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
trait Pointee { type Pointer; }
impl<T> Pointee for [T] { type Pointer = (u32, u32); }
#[cfg_attr(flux, flux::refined_by(pointer: <T as Pointee>::Pointer))]
struct Ptr<T: ?Sized + Pointee> { #[cfg_attr(flux, flux::field(T::Pointer[pointer]))] pointer: T::Pointer }
#[cfg_attr(flux, flux::sig(fn(&Ptr<[T]>[@p]) -> u32[p.pointer.1]))]
pub fn count<T>(pointer: &Ptr<[T]>) -> u32 { pointer.pointer.1 }
