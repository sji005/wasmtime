#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
trait Pointee { type Pointer; }
impl<T> Pointee for [T] { type Pointer = (u32, u32); }
struct Ptr<T: ?Sized + Pointee> { pointer: T::Pointer }
#[cfg_attr(flux, flux::sig(fn(&Ptr<[T]>) -> u32[0]))]
pub fn count<T>(pointer: &Ptr<[T]>) -> u32 { pointer.pointer.1 }
