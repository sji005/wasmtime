#![allow(dead_code)]
#[cfg(flux)] extern crate flux_core;
#[cfg_attr(flux, flux::refined_by(pointer: (int, int)))]
pub struct DirectPtr {
    #[cfg_attr(flux, flux::field((u32[pointer.0], u32[pointer.1])))]
    pointer: (u32, u32),
}
#[cfg_attr(flux, flux::sig(fn(&DirectPtr[@p]) -> u32[p.pointer.1]))]
pub fn count(pointer: &DirectPtr) -> u32 { pointer.pointer.1 }
